﻿using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using UnityEngine;

public class MoonMovement : MonoBehaviour
{
    public float speed = 10f;
    public Transform target;
    public Vector3 TargetPosition = Vector3.zero;

    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject, 5);
        TargetPosition = GameObject.Find("starShip").transform.position;
        TargetPosition = TargetPosition * 30;



    }

    // Update is called once per frame
    void Update()
    {
        float step = speed * Time.deltaTime; // calculate distance to move
        transform.position = Vector3.MoveTowards(transform.position, TargetPosition, step);

      

    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        Destroy(gameObject);
    }
}
